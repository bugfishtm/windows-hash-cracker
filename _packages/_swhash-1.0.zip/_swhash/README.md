# 📦 Hash Cracker

## 📙 Information

A Windows application for brute-forcing and analyzing password hashes using customizable character sets and multiple hash algorithms.

🐟 Bugfish